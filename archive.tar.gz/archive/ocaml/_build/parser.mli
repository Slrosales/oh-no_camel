type token =
  | BOOL of (
# 7 "parser.mly"
        bool
# 6 "parser.mli"
)
  | INT of (
# 8 "parser.mly"
        int
# 11 "parser.mli"
)
  | FLOAT of (
# 9 "parser.mly"
        float
# 16 "parser.mli"
)
  | NOT
  | MINUS
  | PLUS
  | MINUS_DOT
  | PLUS_DOT
  | AST_DOT
  | SLASH_DOT
  | EQUAL
  | LESS_GREATER
  | LESS_EQUAL
  | GREATER_EQUAL
  | LESS
  | GREATER
  | IF
  | THEN
  | ELSE
  | IDENT of (
# 26 "parser.mly"
        Id.t
# 37 "parser.mli"
)
  | LET
  | IN
  | REC
  | COMMA
  | ARRAY_CREATE
  | DOT
  | LESS_MINUS
  | SEMICOLON
  | LPAREN
  | RPAREN
  | EOF

val exp :
  (Lexing.lexbuf  -> token) -> Lexing.lexbuf -> Syntax.t
